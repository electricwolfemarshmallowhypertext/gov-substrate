# Offline verification of H-001

Two runs of one synthetic housing referral, using one reviewer decision. Each run has its own SQLite and witness history. The bundle contains the original synthetic event exports and witness records. It omits the databases, credentials, TLS material and host logs.

Use the Governance Substrate source at commit 908311810edd7a086aa37a9d43faa56b1924a9ac. In a Python environment with the project and its test dependencies installed (python -m pip install ".[test]"), run from the source root with assertions enabled. Extract this ZIP into a directory named h001-evidence under that root.

    python -B tests/housing_referral.py --verify h001-evidence/d804377f2f058757
    python -B tests/housing_referral.py --verify h001-evidence/7f10353f7508a107

The verifier recomputes the event chain in audit.json and checks every event ID, hash and predecessor against witness.json and the final head.json. Each command must exit zero and print the expected head in the evaluation report. journal.jsonl contains the durable witness entries. receipt.json records the final state, review reason, observed revocations and source file fingerprints. MANIFEST.json gives byte-level SHA-256 values for the ten run artifacts and this guide.

For the case outcome, inspect event 27 (closure denied), 32 and 33 (escalation and linked approval), 38 and 39 (withdrawal), and 40 (stale approval denied). The expected persisted referral and positive-control rows are in the final audit snapshot and receipt. The verifier checks consistency of the archived records. It does not authenticate the reviewer or independently attest the host, and the archived witness response has no portable signature. Use the separately distributed archive digest and reported witness heads when comparing copies.
